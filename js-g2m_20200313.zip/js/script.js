var maVariable1 = "Hello World";
console.log(maVariable1);

var maVariable2 = true; // Affectation d’une nouvelle valeur 'true' de type booléen
console.log(maVariable2); // Boolean

var maVariable3 = 0; // Affectation d’un Entier
console.log(maVariable3); // 0
while (maVariable3 < 5) { // Boucle while, avec opérateur
  console.log(maVariable3); // Integer
  maVariable3++; // Incrémentation
}

console.log(maVariable1);
console.log(maVariable2);
console.log(maVariable3);

// prompt() – boîte de dialogue pour saisir un message
let prenom = prompt("Entrez votre prénom :");
console.log(prenom); // ta saisi
// alert() – boîte de dialogue pour afficher de la chaine de caractère
//alert("Bonjour, " + prenom);

// Si prénom indéfini
if (!prenom || prenom == "") {
    prenom = "toto"; // alors se nomme 'toto'
  }
  console.log(prenom);

// Declaration d'une fonction
function direBonjour(param1) {
    // Instruction à executer
    console.log("Bonjour "+param1+" !");
  }
  
  console.log("Début du programme");
  direBonjour(prenom); // Appel de la fonction
  direBonjour("tata"); // Appel de la fonction
  console.log("Fin du programme");

  // Création d'un objet JS -- C'est comme un .json !
console.log("Création d'un objet JS");
let monObjet = {};
// Gestion des erreurs
try {
  // Init
  monObjet = {
    _prenom : prenom, // propriété 'prenom', valeur de la variable 'prenom' : string
    _direBonjour() { // methode : fonction dediée à l'objet
      // Retourne une chaine de caractère
      return "Bonjour, je suis "+this._prenom;
    }
  }
} catch(error) {
  console.log("Impossible de créer l'objet JS !");
}
// Fin de création
console.log("Objet JS créé ! ");
console.log(monObjet);

console.log(monObjet._direBonjour());

// Afficher la description dans <p> dont l'identifiant est 'description' 
document.getElementById("presentation").textContent = monObjet._direBonjour();

// Ma classe JS nommée City
class City {

    // 5 propriétés de l'objet initialisées par le constructeur
    constructor(nomVille, nomPays, nbreHabitants, latitude, longitude ) {
      this.ville = nomVille;  // String
      this.pays = nomPays;// String
      this.habitants = nbreHabitants; // Integer
      this.lat = latitude; // Number
      this.long = longitude // Number
    }
  };
  
  // Instanciation d'un premier objet sans preciser de paramètre
  let ville0 = new City();
  console.log(ville0);
  ville0.prenom = "toto";
  // Instanciation d'un second objet avec paramètres
  let ville1 = new City("Marseille", "France", 861635, 43.300000, 5.400000);
  console.log(ville1);

  // Déclaration d'un tableaux JS [...]
var monTableau = [
    // 1 er élément
    ville0,// virgule comme séparateur
     // 2nd élément
    ville1,
    // 3ème élément
    new City("Lille", "France", 232741, 50.6365654, 3.0635282) // pas de virgule car dernier
  ]
  console.log(monTableau);
  console.log(monTableau.length); // nombre d'élément
  
  // Ajouter un élément : push
  monTableau.push(new City("Rio", "Brésil", 6320000, -22.9110137, -43.2093727));
  
  console.log(monTableau);
  console.log(monTableau.length);
  


