var jsonObject = { "type": "FeatureCollection", "features": [{"type":"Feature","properties":{"VolcanoID":211001,"V_Name":"Larderello","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":43.25,"Longitude":10.87,"PEI":4,"H_active":0,"VEI_Holoce":"3","hazard":"NULL","class":"U-HR","risk":"NULL","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[10.87,43.25]}},{"type":"Feature","properties":{"VolcanoID":211003,"V_Name":"Vulsini","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":42.6,"Longitude":11.93,"PEI":5,"H_active":0,"VEI_Holoce":"Unknown VEI","hazard":"NULL","class":"U-HR","risk":"NULL","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[11.93,42.6]}},{"type":"Feature","properties":{"VolcanoID":211004,"V_Name":"Alban Hills","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":41.73,"Longitude":12.7,"PEI":7,"H_active":0,"VEI_Holoce":"No confirmed eruptions","hazard":"NULL","class":"U-NHHR","risk":"NULL","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[12.7,41.73]}},{"type":"Feature","properties":{"VolcanoID":211010,"V_Name":"Campi Flegrei","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":40.827,"Longitude":14.139,"PEI":7,"H_active":1,"VEI_Holoce":"5","hazard":"3","class":"NULL","risk":"3","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[14.139,40.827]}},{"type":"Feature","properties":{"VolcanoID":211020,"V_Name":"Vesuvius","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":40.821,"Longitude":14.426,"PEI":7,"H_active":1,"VEI_Holoce":"5","hazard":"3","class":"NULL","risk":"3","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[14.426,40.821]}},{"type":"Feature","properties":{"VolcanoID":211030,"V_Name":"Ischia","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":40.73,"Longitude":13.897,"PEI":5,"H_active":0,"VEI_Holoce":"3","hazard":"NULL","class":"U-HR","risk":"NULL","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[13.897,40.73]}},{"type":"Feature","properties":{"VolcanoID":211031,"V_Name":"Palinuro","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":39.48,"Longitude":14.83,"PEI":2,"H_active":0,"VEI_Holoce":"Unknown VEI","hazard":"NULL","class":"U-HR","risk":"NULL","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[14.83,39.48]}},{"type":"Feature","properties":{"VolcanoID":211040,"V_Name":"Stromboli","Country":"Italy","Region":"Mediterranean and W Asia","Subregion":"Italy","Latitude":38.789,"Longitude":15.213,"PEI":3,"H_active":1,"VEI_Holoce":"3","hazard":"1","class":"NULL","risk":"1","field_14":null,"field_15":null},"geometry":{"type":"Point","coordinates":[15.213,38.789]}}]};

/*************************************************
 * 
 * 15/07/2020
 * Examen JavaScript - Rattrapage G2M - durée 3h
 * 
 *************************************************/

/** 
 * OpenStreetMap
 * @type {module:ol/source/OSM}
 */
var osm = new ol.source.OSM();
var osmLayer = new ol.layer.Tile({
	source: osm
});

/** 
 * Couche vecteur point : eruptions volcaniques
 * @type {module:ol/layer/Vector~Options}
 */
var vectorLayer = new ol.layer.Vector({
	source: new ol.source.Vector({
		features: (new ol.format.GeoJSON()).readFeatures(jsonObject) // Source JSON WGS84*/
	})
});
vectorLayer.getSource().getFeatures().forEach(function (feature) { // Reprojection des points de la couche en Web Mercator
	feature.setGeometry(
		new ol.geom.Point(ol.proj.fromLonLat([feature.getGeometry().getCoordinates()[0], feature.getGeometry().getCoordinates()[1]]))
	)
});

/**
 * Carte
 * @type {module:ol/Map~Options}
 */
const map = new ol.Map({

	target: 'map', // Containeur HTML

	/* Tableaux des couches */
	layers: [
		osmLayer,
		vectorLayer
	],

	/*
	 * Définition de la vue representant la carte
	 * Projection : defaults to 'EPSG:3857'
	 * @type {module:ol/source/TileArcGISRest~Options}
	 */
	view: new ol.View({
		center: ol.proj.fromLonLat([10, 17]),
		zoom: 3
	})

});