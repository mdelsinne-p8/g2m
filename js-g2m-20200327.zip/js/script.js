/**
 * Chargement des modules ArcGIS
 */
require([
    "esri/Map",
	"esri/views/MapView"
], function (Map, MapView) {

    // Objet Map ArcGIS
    var map = new Map({
        basemap: "topo-vector"
    });

    // Carte 2D
    view = new MapView({
        container: "viewDiv",
        map: map,
        center: [2.294481, 48.858370], // Paris WGS84
        zoom: 10
    });

    /*
    // Carte 3D
    var view = new SceneView({
        container: "viewDiv",
        map: map,
        camera: {
          position: {  // observation point
            x: -118.80800,
            y: 33.96100,
            z: 25000 // altitude in meters
          },
          tilt: 65  // perspective in degrees
        }
    });
    */
});