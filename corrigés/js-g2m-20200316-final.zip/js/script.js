/**
 * 20/03/2020
 * Initiation à OpenLayers
 */

/**
 * Classe : City
 * Propriétés : ville, pays, habitants, lat, long
 */
class City {

    // 5 propriétés de l'objet initialisées par le constructeur
    constructor(nomVille, nomPays, nbreHabitants, latitude, longitude) {
        this.ville = nomVille; // String
        this.pays = nomPays; // String
        this.habitants = nbreHabitants; // Integer
        this.lat = latitude; // Number
        this.long = longitude // Number
    }

    // Fonction dédiée à un objet instance de City
    getCoordinates() {
        // Instruction de ma fonction
        // retourne un objet X Y

        return {x: this.long, y: this.lat}
    }

};

// Instanciation d'un premier objet sans preciser de paramètre
let ville0 = new City();

// Instanciation d'un second objet avec paramètres
let ville1 = new City("Marseille", "France", 861635, 43.300000, 5.400000);
console.log(ville1.getCoordinates())

// Déclaration d'un tableaux JS [...]
var monTableau = [
    // 1 er élément
    ville0, // virgule comme séparateur
    // 2nd élément
    ville1,
    // 3ème élément
    new City("Lille", "France", 232741, 50.6365654, 3.0635282) // pas de virgule car dernier
]

// Ajouter un élément : push
monTableau.push(new City("Rio", "Brésil", 6320000, -22.9110137, -43.2093727));

// Afficher le tableau dans la console
console.log(monTableau); // afficher le tableau dans la console

/**
 * propriété 'length' (attribut) du tableau :
 * Retourne le nombre d'élément (entier)
 */
console.log(monTableau.length); // 4 

var index = 0; // index du tableau
while (index < monTableau.length) { // Boucle sur tous les éléments du tableau

    try {
        var element = monTableau[index];
        if (element.ville != undefined) { // Exclure les villes 'undefined'
            console.log(element.ville + " ::: x:" + element.getCoordinates().x.toString() + " y:" + element.getCoordinates().y.toString());
        }
    } catch (error) {
        console.log("Erreur rencontrée en parcourant les éléments du tableau");
        console.log(error);
    }

    index++; // Incrémentation de l'index
}

// Raster OpenStreetMap
var osm = new ol.source.OSM();

// Map OpenLayers
const map = new ol.Map({
    target: 'map', // nom de la <div> HTML

    controls: ol.control.defaults().extend([
        // mini-map - vue générale
        new ol.control.OverviewMap({
            layers: [
                new ol.layer.Tile({ source: osm })
            ],
            className: "ol-overviewmap"
        }),
        new ol.control.FullScreen(),   // Plein-écran
        new ol.control.ScaleLine()   // Echelle
    ]),

    // Tableau des couches de la carte
    layers: [
        new ol.layer.Tile({source: osm}) // Couche de la carte
    ],
    // Vue initiale
    view: new ol.View({
        center: ol.proj.fromLonLat([2.294481, 48.858370]), // Paris WGS84
        zoom: 6
    })
});

map.on('click', function(event){alert('click')});